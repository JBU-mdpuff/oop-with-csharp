public class TextStorage
{
    public string FullText => _fullText;
    private string _fullText;
    
    public void Open(string filePath)
    {
        using (StreamReader reader = new StreamReader(filePath))
        {
            _fullText = reader.ReadToEnd();
        }
        Console.WriteLine($"> read file result {_fullText.Length}");
    }
}