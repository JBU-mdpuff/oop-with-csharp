public interface ITextFinder
{
    public string GetName();
    public int FindFirst(string pattern, out int comparisonCount);
    public int FindOccurrences(string pattern);
}