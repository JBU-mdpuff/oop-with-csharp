﻿// See https://aka.ms/new-console-template for more information
using System.Diagnostics;
string constitution = @"../../../res/constitution.txt";
string worstcase = @"../../../res/worstcase.txt";
List<ITextFinder> finders = new List<ITextFinder>();
finders.Add(new BruteForceFinder("BruteForce"));
finders.Add(new KmpFinder("KMP"));
TextStorage storage = new TextStorage();

for (int i = 0; i < finders.Count; i++)
{
    if (finders[i] is BruteForceFinder)
        (finders[i] as BruteForceFinder).SetStorage(storage);
    else if (finders[i] is KmpFinder)
        (finders[i] as KmpFinder).SetStorage(storage);
}

while (true)
{
    Console.WriteLine("> Which File ? 1) constitution , 2) worstcase , Q) quit");
    string rl = Console.ReadLine();
    if (rl.ToUpper() == "Q")
        break;

    if (rl == "1")
    {
        storage.Open(constitution);
    }
    else if (rl == "2")
    {
        storage.Open(worstcase);
    }
    else
        continue;

    while (true)
    {
        Console.WriteLine("> write pattern to find (Q to Quit)");
        string pattern = Console.ReadLine();
        if (pattern == "Q")
            break;

        for (int i = 0; i < finders.Count; i++)
        {
            int comparisonCount;
            int matchIndex = finders[i].FindFirst(pattern, out comparisonCount);
            int occurrences = finders[i].FindOccurrences(pattern);
            Console.WriteLine($"{finders[i].GetName()} >  pattern at : {TextUtil.GetSurroundingText(storage.FullText,matchIndex, 10)} , compares : {comparisonCount} , founds : {occurrences}"); 
        }
    }
}