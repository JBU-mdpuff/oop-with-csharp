
public class BruteForceFinder : ITextFinder{

    private TextStorage _storage;

    private string _name;

    public BruteForceFinder(string name)
    {
        _name = name;
    }

    public string GetName() => _name;

    public void SetStorage(TextStorage storage)
    {
        _storage = storage;
    }

    public int FindFirst(string pattern, out int comparisonCount)
    {
        int matchIndex = BruteForce(pattern, 0, out comparisonCount);
        if (matchIndex != -1)
        {
            return matchIndex;
        }
        else
        {
            return -1;
        }
    }

    public int FindOccurrences(string pattern)
    {
        int count = 0;
        int index = 0;

        while (index <= _storage.FullText.Length - pattern.Length)
        {
            int match = BruteForce( pattern, index , out int _);
            if (match == -1)
                break;

            count++;
            index = match + pattern.Length;
        }
        
        return count;
    }

    private int BruteForce(string pattern,int startIndex,out int comparisonCount)
    {
        int textLength = _storage.FullText.Length;
        int patternLength = pattern.Length;
        comparisonCount = 0;

        for (int i = startIndex; i <= textLength - patternLength; i++)
        {
            int j = 0;
            while (j < patternLength && _storage.FullText[i + j] == pattern[j])
            {
                comparisonCount++;
                j++;
            }

            if (j < patternLength)
            {
                comparisonCount++; // 틀린 글자에서 한 번 더 비교
            }

            if (j == patternLength)
            {
                return i;
            }
        }

        return -1;
    }
}