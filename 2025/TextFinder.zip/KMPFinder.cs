
public class KmpFinder : ITextFinder
{
    private TextStorage _storage;

    private string _name;

    public KmpFinder(string name)
    {
        _name = name;
    }

    public string GetName() => _name;

    public void SetStorage(TextStorage storage)
    {
        _storage = storage;
    }
    public int FindFirst(string pattern,out int comparisonCount)
    {
        int[] lps = BuildLpsArray(pattern);
        int matchIndex = KmpSearch(pattern,0,lps,out comparisonCount);
        if (matchIndex != -1)
        {
            return matchIndex;
        }
        else
        {
            return -1;
        }
    }

    public int FindOccurrences(string pattern)
    {
        int count = 0;
        int index = 0;
        int[] lps = BuildLpsArray(pattern);

        while (index <= _storage.FullText.Length - pattern.Length)
        {
            int match = KmpSearch(pattern, index, lps,out int _);
            if (match == -1)
                break;

            count++;
            index = match + pattern.Length;
        }

        return count;
    }

    private int KmpSearch(string pattern, int startIndex, int[] precomputedLps,out int comparisonCount)
    {
        int[] lps = precomputedLps;
        int i = startIndex;
        int j = 0;
        comparisonCount = 0;
        while (i < _storage.FullText.Length)
        {
            comparisonCount++;
            if (_storage.FullText[i] == pattern[j])
            {
                i++;
                j++;

                if (j == pattern.Length)
                    return i - j;
            }
            else
            {
                if (j != 0)
                {
                    j = lps[j - 1];
                }
                else
                {
                    i++;
                }
            }
        }

        return -1;
    }

    // LPS 배열 생성
    private int[] BuildLpsArray(string pattern)
    {
        int length = 0;
        int i = 1;
        int[] lps = new int[pattern.Length];
        lps[0] = 0;
        while (i < pattern.Length)
        {
            if (pattern[i] == pattern[length])
            {
                length++;
                lps[i] = length;
                i++;
            }
            else
            {
                if (length != 0)
                {
                    length = lps[length - 1];
                }
                else
                {
                    lps[i] = 0;
                    i++;
                }
            }
        }

        return lps;
    }
}
