public class TextUtil
{
    // Utility - 구간 출력
    public static string GetSurroundingText(string _fullText,int index, int range)
    {
        if (index < 0 || index >= _fullText.Length)
            return string.Empty;

        int start = Math.Max(0, index - range);
        int end = Math.Min(_fullText.Length - 1, index + range);

        return _fullText.Substring(start, end - start + 1).Trim();
    }
}