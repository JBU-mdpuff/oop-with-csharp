﻿using TestClass;

Player player = new Player();
Monster monster = new Monster();
Boss boss = new Boss();

// Updatable 인터페이스로 참조
List<Updatable> actorList = new List<Updatable>();
actorList.Add(player);
actorList.Add(monster);
actorList.Add(boss);

player.Attack(monster);
player.Attack(boss);
monster.Attack(player);

for(int i = 0; i < actorList.Count ; i++)
{
    actorList[i].Update();
}

