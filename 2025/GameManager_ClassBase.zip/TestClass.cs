namespace TestClass;

public class Lecture{
    private int _firstMember;
    private bool _firstMemberIsModified = false;
    public int FirstMember{
        get => _firstMember;
        set { 
            _firstMember = value;
            _firstMemberIsModified = true;
        }
    }

    public Lecture()
    {
        _firstMember = 0;
        Console.WriteLine("Initializer With no args");
    }

    public Lecture(int initialFirstMember)
    {
        _firstMember = initialFirstMember;
        Console.WriteLine($"Initializer With args {initialFirstMember}");
    }

    public int FirstMember2 => _firstMember;

    public int GetFirstMember() // getter
    {
        return _firstMember;
    }

    public void SetFirstMember(int aValue) // setter
    {
        _firstMember = aValue;
    }
}


// Game Object
public class Actor {
    private int _health;
    protected int _atk;

    public virtual void Attack(Actor target){
        target.Hit(_atk);
    }

    public virtual void Hit(int damage)
    {
        _health -= damage;
    }
}
public interface Updatable{
    public void Update();
}

public interface Walkable{
    public void UpdateWalk();
}

public class Player : Actor , Updatable , Walkable {
    public override void Attack(Actor target)
    {
        target.Hit(_atk);
        Console.WriteLine("Player overrided Attack");
    }

    // implements interface Updatable
    public void Update() 
    {
        //
    }

    // implements interface Walkable
    public void UpdateWalk() 
    {
        //
    }
}

public class Monster : Actor , Updatable,Walkable {
    public override void Attack(Actor target)
    {
        base.Attack(target);
        Console.WriteLine("Monster overrided Attack");
        // overrided Attack from Actor 
        // but uses base method
    }

    public void Update()
    {
    }

    public void UpdateWalk()
    {
    }
}

public class Boss : Actor,Updatable,Walkable {
    
    // boss didn't implement ( override ) Attack

    public void Update()
    {
    }

    public void UpdateWalk()
    {
    }
}

