using StudentManager.Models;
using System.ComponentModel;

// Student ViewModel 에 대한 네임스페이스를 지정합니다.
namespace StudentManager.ViewModels;


// 데이터 ( 뷰모델 ) 의 변경사항을 뷰에 알리기 위해 아래 인터페이스를 통해 옵저버 패턴을 구현합니다.
// INotifyPropertyChanged 
public class StudentViewModel : INotifyPropertyChanged{
    
    // Model 은 private 로 접근을 제한 합니다.
    private Student _data;

    public StudentViewModel(Student data)
    {
        _data = data;
    }

    public string Name{
        get => _data.Name;
        set{
            if(_data.Name != value)
            {
                _data.Name = value;
                OnPropertyChanged("Name");
            }
        }
    }

    public string ID{
        get => _data.ID;
        set{
            if(_data.ID != value)
            {
                _data.ID = value;
                OnPropertyChanged("ID");
            }
        }
    }

    public float Score{
        get => _data.Score;
        set{
            if(_data.Score != value)
            {
                _data.Score = value;
                OnPropertyChanged("Score");
            }
        }
    }


    // Observer 패턴의 구현을 통해 이 객체의 Subscriber ( 이 프로젝트의 경우에 View ) 에게 프로퍼티의 변경을 알립니다.
    public event PropertyChangedEventHandler? PropertyChanged;

    public void OnPropertyChanged(string propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}