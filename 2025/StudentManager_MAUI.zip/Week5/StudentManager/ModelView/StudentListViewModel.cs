using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Reflection;
using StudentManager.Models;


// Student List VideModel 에 대한 네임스페이스를 지정합니다.
namespace StudentManager.ViewModels;

public class StudentListViewModel : INotifyPropertyChanged{

    // ObservableCollection 은 MAUI프레임워크에서 콜렉션의 내용 변화를 View에 알릴 수 있는 특수한 자료구조 입니다.
    // 
    public ObservableCollection<StudentViewModel> Students {get;private set;}
    public List<StudentViewModel> StudentAsList {get;private set;}
    private List<Student> _dataSource;

    // 뷰모델이 생성될 때 자료 구성
    public StudentListViewModel()
    {
        PushData();
    }

    // 초기화 함수를 구성합니다.
    // 생성자 내부는 최대한 간결하게 유지하도록 합니다.
    private void PushData()
    {
        // 패키지의 Resources / Raw / random_student_data.csv 를 읽기
        ReadResources("random_student_data.csv");

        StudentAsList = new List<StudentViewModel>();
        for(int i = 0; i < _dataSource.Count ; i++)
        {
            StudentAsList.Add(new StudentViewModel(_dataSource[i]));
        }
        Students = new ObservableCollection<StudentViewModel>(StudentAsList);

        // 데이터를 불러온 후, 뷰에 해당 프로퍼티의 변경을 알립니다.
        OnPropertyChanged("Students");
    }

    private async void ReadResources(string filename)
    {   
        // 데이터를 수용할 모델의 리스트 자료구조 초기화 
        _dataSource = new List<Student>();

        // FireSystem.OpenAppPackageFileAsync 를 통해 패키지에 포함된 파일을 엽니다
        var stream = await FileSystem.OpenAppPackageFileAsync(filename);
        var reader = new StreamReader(stream);

        // 텍스트 스트림은 한줄씩 읽거나 한번에 모두 읽을 수 있습니다.
        // 우리가 읽는 csv 포맷은 데이터가 line by line 으로 이루어져 있기 때문에
        // 편의상 루프에서 한 문자열 라인씩 읽도록 합니다.
        string rl = reader.ReadLine();
        
        while(!string.IsNullOrEmpty(rl))
        {
            _dataSource.Add(ParseStudent(rl));
            rl = reader.ReadLine();
        }
    }

    // 문자열로부터 Student 객체를 구성해내는 함수를 작성하여 
    // 차후에 Student 객체가 수정되는 상황에 조금 더 간결하고 유연하게 대처할 수 있도록 합니다.
    private Student ParseStudent(string rawdata)
    {
        string[] tokens = rawdata.Split(",");
        float score = 0;
        if(float.TryParse(tokens[2],out float parsed))
            score = parsed;
        return new Student(tokens[0],tokens[1],score);
    }


    public event PropertyChangedEventHandler? PropertyChanged;

    public void OnPropertyChanged(string propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}