namespace StudentManager.Models;


// 데이터 객체 ( model ) 을 정의합니다.
public class Student{
    public string Name;
    public string ID;
    public float Score;

    public Student(string name,string id,float score)
    {
        Name = name;
        ID = id;
        Score = score;
    }
}