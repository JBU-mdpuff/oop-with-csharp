using StudentManager.ViewModels;
namespace StudentManager.Views
{
    public partial class StudentListView : ContentPage
    {
        public StudentListView()
        {
            InitializeComponent();
            BindingContext = new StudentListViewModel();
        }
    }
}